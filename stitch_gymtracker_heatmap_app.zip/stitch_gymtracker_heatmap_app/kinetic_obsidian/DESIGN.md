---
name: Kinetic Obsidian
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e11'
  surface-container-low: '#1a1c1f'
  surface-container: '#1e2023'
  surface-container-high: '#282a2d'
  surface-container-highest: '#333538'
  on-surface: '#e2e2e6'
  on-surface-variant: '#c2cab0'
  inverse-surface: '#e2e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#8c947c'
  outline-variant: '#424936'
  surface-tint: '#98da27'
  primary: '#ccff80'
  on-primary: '#213600'
  primary-container: '#a3e635'
  on-primary-container: '#416400'
  inverse-primary: '#446900'
  secondary: '#4ae176'
  on-secondary: '#003915'
  secondary-container: '#00b954'
  on-secondary-container: '#004119'
  tertiary: '#def1ff'
  on-tertiary: '#00354a'
  tertiary-container: '#9ddaff'
  on-tertiary-container: '#006184'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b2f746'
  primary-fixed-dim: '#98da27'
  on-primary-fixed: '#121f00'
  on-primary-fixed-variant: '#334f00'
  secondary-fixed: '#6bff8f'
  secondary-fixed-dim: '#4ae176'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005321'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#111317'
  on-background: '#e2e2e6'
  surface-variant: '#333538'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
  timer-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 56px
  timer-display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 44px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is engineered for elite athletic performance, tracking, and strength progression. It targets disciplined lifters, athletes, and fitness enthusiasts who demand precision, high legibility under gym lighting conditions, and immediate feedback during physical exertion.

The aesthetic fuses **Athletic High-Contrast Modernism** with **Subtle Dark Glassmorphism**. The visual identity relies on an ultra-deep charcoal canvas paired with high-energy kinetic lime and emerald accents. This drives an atmosphere of raw focus, physiological vitality, and technological precision. Interfaces eliminate cognitive friction: primary actions, progress meters, sets, and rest intervals project forcefully against low-luminance backdrops.

## Colors

The palette establishes an aggressive hierarchy tuned for OLED displays and dimly lit training floors:

- **Primary Accent (`#A3E635` - Kinetic Lime):** The apex focal point. Reserved for active states, primary CTA buttons ("Iniciar Treino", "Concluir Série"), high-intensity PR badges, and the topmost tier of consistency grids.
- **Secondary Accent (`#22C55E` - Vivid Emerald):** Indicates successful completion, baseline streak tracking, checkmarks, and positive delta values.
- **Tertiary Accent (`#38BDF8` - Electric Cyan):** Used sparingly for secondary telemetry such as rest timers, hydration, and RPE/cadence indicators.
- **Neutral Canvas Hierarchy:**
  - **Canvas Base (`#0D0F12`):** Primary background layer.
  - **Surface Level 1 (`#161A20`):** Base cards, modular widgets, list containers.
  - **Surface Level 2 (`#1F242D`):** Elevated modals, segmented tabs, active inputs, inner table cells.
  - **Surface Level 3 / Active Tint (`#282E3A`):** Interactive card hovers, deactivated chips, stroke boundaries.
- **Text & Foreground:**
  - **Primary Content:** `#F8FAFC` (97% White).
  - **Muted Content:** `#94A3B8` (Slate 400).
  - **Subtle / Inactive:** `#475569` (Slate 600).
- **Consistency Matrix Tiers (GitHub-style workout matrix):**
  - Level 0 (Rest): `#161A20`
  - Level 1 (Light Activity): `#14532D`
  - Level 2 (Moderate Volume): `#16A34A`
  - Level 3 (Full Target Hit): `#22C55E`
  - Level 4 (Overload / PR Achieved): `#A3E635`

## Typography

The typographic engine uses **Plus Jakarta Sans** uniformly across headlines, metrics, labels, and running text to ensure structural consistency, broad glyph aperture, and optimal legibility at dynamic distances.

### Key Rules
- **Numerical Emphasis:** Timers, weights (kg/lbs), reps, and personal record tracking use heavy font weights (`700` and `800`) with tabular figures (`font-variant-numeric: tabular-nums`) to prevent horizontal layout shifting during real-time rep and rest counting.
- **Uppercase Metadata:** Muscle group labels, target metrics, and table column titles ("SÉRIE", "KG", "REPS", "RPE") are typeset using `label-sm` or `label-md` with `letter-spacing: 0.05em` to anchor secondary technical information without visual crowding.

## Layout & Spacing

The layout is built around a mobile-first fluid model optimized for one-handed operation during workouts:

- **Base Rhythm:** Built strictly upon a 4px/8px incremental grid.
- **Margins & Gutter:** Handheld mobile interfaces enforce a continuous `1rem` (16px) lateral margin and `1rem` column gutters. Tablet adaptations scale horizontal margins to `1.5rem` (24px) or `2rem` (32px), introducing a dual-column exercise workspace.
- **Thumb-Zone Prioritization:** All immediate workout modifications (finishing sets, increasing load, starting rest timers) occupy the bottom 40% of the screen. Non-critical historical analytics sit in the top fluid scroll area.
- **Micro-Gaps:** Compact component relationships (e.g., set rows within an exercise card) utilize `space-xs` (4px) and `space-sm` (8px) gaps to pack dense workout telemetry onto the screen without visual clutter.

## Elevation & Depth

Visual hierarchy is maintained through disciplined tonal staging combined with delicate border highlighting and selective backdrop filters:

- **Tonal Layers:** Deepest operations happen on `#0D0F12`. Modules sit upon `#161A20`. Interactive items pop out on `#1F242D`.
- **Ghost Outlines:** Instead of heavy drop shadows that muddy dark themes, containers utilize a thin, low-contrast 1px perimeter border: `rgba(255, 255, 255, 0.08)`.
- **Subtle Glassmorphism:** Sticky headers, floating action docks, and resting timer banners use a translucent surface: `background: rgba(22, 26, 32, 0.82)` with `backdrop-filter: blur(16px)` and a top border highlight of `rgba(255, 255, 255, 0.12)`.
- **Neon Proximity Glow:** Key active elements (such as an underway set or an active rest timer) carry an ambient, localized drop shadow: `box-shadow: 0 0 24px rgba(163, 230, 53, 0.15)`.

## Shapes

The design system implements a roundedness level of `2`:

- **Primary Cards & Modals:** Standardized on `rounded-2xl` (1rem / 16px to 1.5rem / 24px depending on container scale) to soften dense structural data and provide a modern app profile.
- **Buttons & Action Controls:** Large touch targets utilize `rounded-xl` (12px) to `rounded-2xl` (16px) for comfortable finger resting.
- **Badges, Chips & Pills:** Muscle group classifications, workout indicators, and set counters use fully rounded pill profiles (`border-radius: 9999px`) to distinguish categorical tags from interactive actionable blocks.
- **Consistency Matrix Cells:** Squares with balanced miniature rounding (`rounded-sm` / 3px - 4px) to avoid visual harshness in dense data grids.

## Components

### Buttons
- **Primary Kinetic Action:** Background `#A3E635`, text `#0D0F12` in bold (`700`). High contrast, instantaneous visibility. Applied to critical workout prompts ("Concluir Série", "Iniciar Treino").
- **Secondary Ghost Action:** Background `#1F242D`, text `#F8FAFC`, border `1px solid rgba(255, 255, 255, 0.1)`. Used for auxiliary triggers ("Adicionar Exercício", "Histórico").
- **Destructive / Caution:** Background `rgba(239, 68, 68, 0.15)`, text `#EF4444`, border `1px solid rgba(239, 68, 68, 0.3)`.

### Exercise & Set Cards
- Encapsulated within `#161A20` with a 1px border `rgba(255, 255, 255, 0.08)`.
- **Active Set Row:** Highlighted with a background tint of `rgba(163, 230, 53, 0.08)` and a left indicator bar in `#A3E635` (3px width).
- **Completed Set Checkbox:** Circular trigger with a soft transition from an outlined state (`#475569`) to a vibrant filled state (`#22C55E`) featuring a crisp dark checkmark.

### Muscle Badges & Chips
- Capsule-shaped pills with uppercase micro-typography (`label-sm`).
- Categorized by muscle groups:
  - Push / Peito / Tríceps: `rgba(163, 230, 53, 0.12)` text `#A3E635`.
  - Pull / Costas / Bíceps: `rgba(56, 189, 248, 0.12)` text `#38BDF8`.
  - Legs / Quadríceps / Isquiotibiais: `rgba(244, 63, 94, 0.12)` text `#F43F5E`.

### GitHub-Style Consistency Grid
- A 7-row matrix representing the days of the week, flowing horizontally over calendar weeks.
- Cells size: 12px x 12px with 3px border radius and 3px spacing.
- Visual steps transition smoothly from `#161A20` (inactivity) to `#14532D`, `#16A34A`, `#22C55E`, and peak performance days at `#A3E635` with ambient illumination.

### Metric Inputs & Number Pickers
- High-contrast, large numerical displays with quick +/- step steppers (`space-sm` separation).
- Background `#1F242D`, active focus border `1px solid #A3E635`.

### Floating Dynamic Timer
- Anchored to the viewport bottom with glassmorphism blur (`16px`).
- Monospaced numerical readouts (`tabular-nums`) displaying elapsed rest time, paired with an SVG progress ring or linear progress accent strip colored in `#38BDF8` or `#A3E635`.